package console_web;

import com.htl.miniserver.MiniServer;

public class Main {
    public static void main(String[] args) {
        MyHttpHandler handler = new MyHttpHandler();
        try {
            MiniServer server = new MiniServer(80);
            server.connect(handler);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
