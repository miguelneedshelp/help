package console_web;

import com.htl.miniserver.*;
import lib.Categories;
import lib.Item;
import lib.ItemManagerImpl;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class MyHttpHandler implements OnHTTPRequest, post {

    private final ItemManagerImpl<Item> itemManager = new ItemManagerImpl<>();
    private static final String JSON_BASE_FILE = "test.json";

    public MyHttpHandler() {
        readData();
    }

    private HTTPResponse createPage(String body) {
        String page = "<html>" +
                "<head>" +
                "<meta charset=\"utf-8\">" +
                "<title>Miguel's Webshop</title>" +
                "<style>" +
                ".body { font-family: 'Courier New', monospace; background-color: #000000; }" +
                ".container { max-width: 1500px; margin: 0 auto; padding: 20px; }" +
                ".header { font-family: 'Courier New', monospace; text-align: center; background-color: #DEDFE8; color: #fff; padding: 20px; }" +
                ".item-container { display: flex; flex-wrap: wrap; justify-content: space-between; }" +
                ".item { width: calc(25% - 20px); background-color: #fff; border: 1px solid #ddd; border-radius: 5px; margin-bottom: 20px; padding: 20px; box-sizing: border-box; }" +
                ".item h2 { margin-top: 0; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "<div class=\"container\">" +
                "<div class='header'><h1>Miguel's Webshop<div class='buttons-container'>" +
                "<form method='get' action='start'>" +
                "<div style='position:relative; left:600px; top:-60px;'>" +
                "<input type='text' name='search' value=''/>" +
                "<input type='submit' name='suchen' value='suchen'/>" +
                "</div>" +
                "</form>" +
                "<button type='button' onclick='handleButtonClick(\"Neu erschienen\")'>Neu erschienen</button>" +
                "<button type='button' onclick='handleButtonClick(\"Icons\")'>Icons</button>" +
                "<button type='button' onclick='handleButtonClick(\"Männer\")'>Männer</button>" +
                "<button type='button' onclick='handleButtonClick(\"Frauen\")'>Frauen</button>" +
                "<button type='button' onclick='handleButtonClick(\"Kinder\")'>Kinder</button>" +
                "<button type='button' onclick='handleButtonClick(\"Brillen\")'>Brillen</button>" +
                "<button type='button' onclick='handleButtonClick(\"Spezielle Stücke\")'>Spezielle Stücke</button>" +
                "<button type='button' onclick='handleButtonClick(\"Homeware\")'>Homeware</button>" +
                "<button type='button' onclick='handleButtonClick(\"Geschenke\")'>Geschenke</button>" +
                "<button type='button' onclick='handleButtonClick(\"Unsere Vision\")'>Unsere Vision</button>" +
                "</div></h1></div>" +
                "<form method='get' action='start'>" +
                "<select name='sortBy' onchange='this.form.submit()'>" +
                "<option value='A_Z'>Alphabetisch, A-Z</option>" +
                "<option value='Z_A'>Alphabetisch, Z-A</option>" +
                "<option value='auP'>Preis, von niedrig zu hoch</option>" +
                "<option value='abP'>Preis, von hoch zu niedrig</option>" +
                "</select>" +
                "</form>" +
                "</div>" +
                body +
                "</div>" +
                "<script>" +
                "function handleButtonClick(category) {" +
                "window.location.href = '/start?category=' + category;" +
                "}" +
                "</script>" +
                "</body>" +
                "</html>";

        return new HtmlResponse(page);
    }

    private HTTPResponse adminPage() {
        String adminHtml = "<h2>Admin Panel</h2>" +
                "<button onclick=\"window.location.href='/admin/create'\">Create Item</button>" +
                "<button onclick=\"window.location.href='/admin/list'\">Show All Items</button>";
        return createPage(adminHtml);
    }

    private HTTPResponse createItemPage() {
        String createForm = "<h2>Create Item</h2>" +
                "<form method='post' action='/admin/add'>" +
                "<label>Marke: <input type='text' name='marke' required></label><br>" +
                "<label>Artikel: <input type='text' name='artikel' required></label><br>" +
                "<label>Preis: <input type='number' name='preis' step='0.01' required></label><br>" +
                "<label>Größe: <input type='text' name='groesse'></label><br>" +
                "<label>Bewertung: <input type='number' name='bewertung' min='1' max='5'></label><br>" +
                "<label>Verfügbarkeit: <input type='checkbox' name='verfuegbarkeit'></label><br>" +
                "<label>Lieferzeit: <input type='number' name='lieferzeit'></label><br>" +
                "<label>Kategorie: <input type='text' name='kategorie'></label><br>" +
                "<input type='submit' value='Add Item'>" +
                "</form>";
        return createPage(createForm);
    }

    private HTTPResponse listItemPage() {
        StringBuilder listHtml = new StringBuilder();
        listHtml.append("<h3>Items</h3>")
                .append("<table border='1'>")
                .append("<tr><th>ID</th><th>Marke</th><th>Artikel</th><th>Preis</th><th>Größe</th><th>Bewertung</th><th>Verfügbarkeit</th><th>Lieferzeit</th><th>Kategorie</th><th>Actions</th></tr>");

        List<Item> items = itemManager.getAllItems();
        for (Item item : items) {
            listHtml.append("<tr>")
                    .append("<td>").append(item.getArtikelID()).append("</td>")
                    .append("<td>").append(item.getMarke()).append("</td>")
                    .append("<td>").append(item.getArtikel()).append("</td>")
                    .append("<td>").append(item.getPreis()).append("€</td>")
                    .append("<td>").append(item.getGroesse()).append("</td>")
                    .append("<td>").append(item.getBewertung()).append("</td>")
                    .append("<td>").append(item.isVerfuegbarkeit() ? "Ja" : "Nein").append("</td>")
                    .append("<td>").append(item.getLieferzeit()).append("</td>")
                    .append("<td>").append(item.getKategorie()).append("</td>")
                    .append("<td>")
                    .append("<form method='post' action='/admin/delete' style='display:inline;'>")
                    .append("<input type='hidden' name='artikelID' value='").append(item.getArtikelID()).append("'>")
                    .append("<input type='submit' value='Delete'>")
                    .append("</form>")
                    .append("<form method='get' action='/admin/edit' style='display:inline;'>")
                    .append("<input type='hidden' name='artikelID' value='").append(item.getArtikelID()).append("'>")
                    .append("<input type='submit' value='Edit'>")
                    .append("</form>")
                    .append("</td>")
                    .append("</tr>");
        }
        listHtml.append("</table>");
        listHtml.append("<button onclick=\"window.location.href='/admin/rewrite'\">Rewrite File</button>");
        return createPage(listHtml.toString());
    }

    private HTTPResponse handleAddItem(HTTPRequest request) {
        try {
            String marke = request.getParameter("marke");
            String artikel = request.getParameter("artikel");
            double preis = Double.parseDouble(request.getParameter("preis"));
            String groesse = request.getParameter("groesse");
            int bewertung = Integer.parseInt(request.getParameter("bewertung"));
            boolean verfuegbarkeit = request.getParameter("verfuegbarkeit") != null;
            int lieferzeit = Integer.parseInt(request.getParameter("lieferzeit"));
            String kategorie = request.getParameter("kategorie");

            Item newItem = new Categories(marke, artikel, itemManager.getAllItems().size() + 1, preis, groesse, bewertung, verfuegbarkeit, lieferzeit, kategorie);
            itemManager.add(newItem);

            return new HtmlResponse("/admin/list") {
            };
        } catch (Exception e) {
            e.printStackTrace();
            return createPage("<p>Error adding item. Please try again.</p>");
        }
    }

    private HTTPResponse handleEditItemPage(HTTPRequest request) {
        try {
            int artikelID = Integer.parseInt(request.getParameter("artikelID"));
            Item item = itemManager.getAllItems().stream().filter(i -> i.getArtikelID() == artikelID).findFirst().orElse(null);

            if (item == null) {
                return createPage("<p>Item not found.</p>");
            }

            String editForm = "<h2>Edit Item</h2>" +
                    "<form method='post' action='/admin/update'>" +
                    "<input type='hidden' name='artikelID' value='" + item.getArtikelID() + "'>" +
                    "<label>Marke: <input type='text' name='marke' value='" + item.getMarke() + "'></label><br>" +
                    "<label>Artikel: <input type='text' name='artikel' value='" + item.getArtikel() + "'></label><br>" +
                    "<label>Preis: <input type='number' name='preis' step='0.01' value='" + item.getPreis() + "'></label><br>" +
                    "<label>Größe: <input type='text' name='groesse' value='" + item.getGroesse() + "'></label><br>" +
                    "<label>Bewertung: <input type='number' name='bewertung' min='1' max='5' value='" + item.getBewertung() + "'></label><br>" +
                    "<label>Verfügbarkeit: <input type='checkbox' name='verfuegbarkeit' " + (item.isVerfuegbarkeit() ? "checked" : "") + "></label><br>" +
                    "<label>Lieferzeit: <input type='number' name='lieferzeit' value='" + item.getLieferzeit() + "'></label><br>" +
                    "<label>Kategorie: <input type='text' name='kategorie' value='" + item.getKategorie() + "'></label><br>" +
                    "<input type='submit' value='Update Item'>" +
                    "</form>";
            return createPage(editForm);
        } catch (Exception e) {
            e.printStackTrace();
            return createPage("<p>Error loading edit form. Please try again.</p>");
        }
    }

    private HTTPResponse handleUpdateItem(HTTPRequest request) {
        try {
            int artikelID = Integer.parseInt(request.getParameter("artikelID"));
            String marke = request.getParameter("marke");
            String artikel = request.getParameter("artikel");
            double preis = Double.parseDouble(request.getParameter("preis"));
            String groesse = request.getParameter("groesse");
            int bewertung = Integer.parseInt(request.getParameter("bewertung"));
            boolean verfuegbarkeit = request.getParameter("verfuegbarkeit") != null;
            int lieferzeit = Integer.parseInt(request.getParameter("lieferzeit"));
            String kategorie = request.getParameter("kategorie");

            Item updatedItem = new Categories(marke, artikel, artikelID, preis, groesse, bewertung, verfuegbarkeit, lieferzeit, kategorie);
            itemManager.update(updatedItem);

            return new HtmlResponse("/admin/list");
        } catch (Exception e) {
            e.printStackTrace();
            return createPage("<p>Error updating item. Please try again.</p>");
        }
    }

    private HTTPResponse handleDeleteItem(HTTPRequest request) {
        try {
            int artikelID = Integer.parseInt(request.getParameter("artikelID"));
            itemManager.delete(artikelID);
            return new HtmlResponse("/admin/list");
        } catch (Exception e) {
            e.printStackTrace();
            return createPage("<p>Error deleting item. Please try again.</p>");
        }
    }

    private HTTPResponse handleRewriteFile() {
        try {
            writeData();
            return createPage("<p>File rewritten successfully!</p>");
        } catch (Exception e) {
            e.printStackTrace();
            return createPage("<p>Error rewriting file. Please try again.</p>");
        }
    }

    private HTTPResponse showItems(HTTPRequest request) {
        List<Item> items = itemManager.getAllItems();

        String category = request.getParameter("category");
        String searchQuery = request.getParameter("search");
        String sortBy = request.getParameter("sortBy");

        if (category != null && !category.isEmpty()) {
            items = items.stream().filter(item -> category.equals(item.getKategorie())).collect(Collectors.toList());
        }

        if (searchQuery != null && !searchQuery.isEmpty()) {
            items = items.stream()
                    .filter(item -> item.getMarke().toLowerCase().contains(searchQuery.toLowerCase()) ||
                            item.getArtikel().toLowerCase().contains(searchQuery.toLowerCase()))
                    .collect(Collectors.toList());
        }

        if (sortBy != null) {
            switch (sortBy) {
                case "A_Z" -> items.sort(Comparator.comparing(Item::getMarke));
                case "Z_A" -> items.sort(Comparator.comparing(Item::getMarke).reversed());
                case "auP" -> items.sort(Comparator.comparingDouble(Item::getPreis));
                case "abP" -> items.sort(Comparator.comparingDouble(Item::getPreis).reversed());
            }
        }

        StringBuilder itemsHtml = new StringBuilder();
        itemsHtml.append("<div class='item-container'>");

        for (Item item : items) {
            itemsHtml.append("<div class='item'>")
                    .append("<h2>").append(item.getMarke()).append("</h2>")
                    .append("<p>").append(item.getArtikel()).append("</p>")
                    .append("<p>Preis: ").append(item.getPreis()).append("€</p>")
                    .append("<p>Größe: ").append(item.getGroesse()).append("</p>")
                    .append("<p>Bewertung: ").append(item.getBewertung()).append("/5</p>")
                    .append("<p>").append(item.isVerfuegbarkeit() ? "Verfügbar" : "Nicht verfügbar").append("</p>")
                    .append("<p>Lieferzeit: ").append(item.getLieferzeit()).append(" Tage</p>")
                    .append("<p>Kategorie: ").append(item.getKategorie()).append("</p>")
                    .append("</div>");
        }

        itemsHtml.append("</div>");

        return createPage(itemsHtml.toString());
    }

    private void writeData() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(JSON_BASE_FILE))) {
            writer.write(itemManager.exportToJSON(JSON_BASE_FILE).toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void readData() {
        try (BufferedReader reader = new BufferedReader(new FileReader(JSON_BASE_FILE))) {
            StringBuilder json = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                json.append("[").append(line).append("],");
            }
            String jsonArrayString = "[" + json.deleteCharAt(json.length() - 1) + "]";
            itemManager.importFromJSON(jsonArrayString);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }




    @Override
    public HTTPResponse onGetRequest(HTTPRequest request) {
        String path = request.getURL();

        return switch (path) {
            case "/start" -> showItems(request);
            case "/admin" -> adminPage();
            case "/admin/create" -> createItemPage();
            case "/admin/list" -> listItemPage();
            case "/admin/edit" -> handleEditItemPage(request);
            case "/admin/rewrite" -> handleRewriteFile();
            default -> new HtmlResponse("/start");
        };
    }

    @Override
    public HTTPResponse onPostRequest(HTTPRequest request) {
        String path = request.getURL();

        return switch (path) {
            case "/admin/add" -> handleAddItem(request);
            case "/admin/update" -> handleUpdateItem(request);
            case "/admin/delete" -> handleDeleteItem(request);
            default -> new HtmlResponse("/admin");
        };
    }
}

