package lib;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ItemManagerImpl<T extends Item> implements itemManager<T> {

    private final List<T> itemList;

    public ItemManagerImpl() {
        this.itemList = new ArrayList<>();
    }

    @Override
    public void add(T item) {
        itemList.add(item);
    }

    @Override
    public void update(int index, String newMarke, String newArtikel, int newArtikelID, double newPreis, String newGroesse, int newBewertung, boolean newVerfuegbarkeit, int newLieferzeit, String newKategorie) {

    }

    @Override
    public void update(T updatedItem) {
        for (int i = 0; i < itemList.size(); i++) {
            if (itemList.get(i).getArtikelID() == updatedItem.getArtikelID()) {
                itemList.set(i, updatedItem);
                return;
            }
        }
    }

    @Override
    public void delete(int index) {
        if (index >= 0 && index < itemList.size()) {
            itemList.remove(index);
        } else {
            System.out.println("Index nicht im range");
        }
    }

    @Override
    public Categories parseCategory(String line) {
        try {
            line = line.trim();
            if (line.startsWith("[") && line.endsWith("]")) {
                line = line.substring(1, line.length() - 1);
            }

            if (line.startsWith("{") && line.endsWith("}")) {
                line = line.substring(1, line.length() - 1);
            }

            String[] keyValuePairs = line.split(",");
            String marke = null;
            String artikel = null;
            int artikelID = 0;
            double preis = 0.0;
            String groesse = null;
            int bewertung = 0;
            boolean verfuegbarkeit = false;
            int lieferzeit = 0;
            String kategorie = null;

            for (String pair : keyValuePairs) {
                String[] parts = pair.split(":");
                if (parts.length != 2) {
                    System.out.println("Nicht gültiges key-value paar: " + pair);
                    continue;
                }
                String key = parts[0].trim().replaceAll("\"", "");
                String value = parts[1].trim().replaceAll("\"", "");

                switch (key) {
                    case "marke" -> marke = value;
                    case "artikel" -> artikel = value;
                    case "artikelID" -> artikelID = Integer.parseInt(value);
                    case "preis" -> preis = Double.parseDouble(value);
                    case "groesse" -> groesse = value;
                    case "bewertung" -> bewertung = Integer.parseInt(value);
                    case "verfuegbarkeit" -> verfuegbarkeit = Boolean.parseBoolean(value);
                    case "lieferzeit" -> lieferzeit = Integer.parseInt(value);
                    case "kategorie" -> kategorie = value;
                    default -> System.out.println("Unbekannter Schlüssel: " + key);
                }
            }
            return new Categories(marke, artikel, artikelID, preis, groesse, bewertung, verfuegbarkeit, lieferzeit, kategorie);
        } catch (Exception e) {
            System.out.println("Ungültiges JSON-Format: " + line);
            e.printStackTrace();
            return null;
        }
    }
    @Override
    public void sort(List<T> list) {
        list.sort(Comparator
                .comparing(Item::getGroesse)
                .thenComparing(Item::isVerfuegbarkeit, Comparator.reverseOrder())
                .thenComparing(Item::getPreis)
                .thenComparingInt(Item::getBewertung));
    }
    @Override
    public List<T> getAllItems() {
        return itemList;
    }

    @Override
    public void exportToCSV(String fileName) {
        try {
            List<String> lines = itemList.stream()
                    .map(Item::toCSV)
                    .collect(Collectors.toList());
            Files.write(Paths.get(fileName), lines);
            System.out.println("Datei erfolgreich exportiert.");
        } catch (IOException e) {
            System.out.println("Fehler beim Exportieren: " + e.getMessage());
        }
    }

    @Override
    public void importFromCSV(String fileName) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(fileName));
            for (String line : lines) {
                String[] parts = line.split(",");
                if (parts.length == 9) {
                    String marke = parts[0];
                    String artikel = parts[1];
                    int artikelID = Integer.parseInt(parts[2]);
                    double preis = Double.parseDouble(parts[3]);
                    String groesse = parts[4];
                    int bewertung = Integer.parseInt(parts[5]);
                    boolean verfuegbarkeit = Boolean.parseBoolean(parts[6]);
                    int lieferzeit = Integer.parseInt(parts[7]);
                    String kategorie = parts[8];
                    itemList.add((T) new Categories(marke, artikel, artikelID, preis, groesse, bewertung, verfuegbarkeit, lieferzeit, kategorie));
                } else {
                    System.out.println("Fehlerhafte Zeile: " + line);
                }
            }
            System.out.println("Datei erfolgreich importiert.");
        } catch (IOException e) {
            System.out.println("Fehler beim Importieren: " + e.getMessage());
        }
    }

    @Override
    public List<T> exportToJSON(String fileName) {
        try {
            List<String> jsonList = itemList.stream()
                    .map(Item::toJSON)
                    .collect(Collectors.toList());
            String jsonString = "[" + String.join(",", jsonList) + "]";
            Files.write(Paths.get(fileName), jsonString.getBytes());
            System.out.println("Datei erfolgreich exportiert.");
        } catch (IOException e) {
            System.out.println("Fehler beim Exportieren: " + e.getMessage());
        }
        return getAllItems();
    }

    @Override
    public void importFromJSON(String fileName) {
        try {
            String jsonString = new String(Files.readAllBytes(Paths.get(fileName)));
            jsonString = jsonString.replace("[", "").replace("]", "");
            String[] jsonArray = jsonString.split("},");
            for (String json : jsonArray) {
                if (!json.endsWith("}")) {
                    json += "}";
                }
                json = json.replace("{", "").replace("}", "");
                String[] parts = json.split(",");
                if (parts.length == 9) {
                    String marke = parts[0].split(":")[1].replace("\"", "");
                    String artikel = parts[1].split(":")[1].replace("\"", "");
                    int artikelID = Integer.parseInt(parts[2].split(":")[1]);
                    double preis = Double.parseDouble(parts[3].split(":")[1]);
                    String groesse = parts[4].split(":")[1].replace("\"", "");
                    int bewertung = Integer.parseInt(parts[5].split(":")[1]);
                    boolean verfuegbarkeit = Boolean.parseBoolean(parts[6].split(":")[1]);
                    int lieferzeit = Integer.parseInt(parts[7].split(":")[1]);
                    String kategorie = parts[8].split(":")[1].replace("\"", "");
                    itemList.add((T) new Categories(marke, artikel, artikelID, preis, groesse, bewertung, verfuegbarkeit, lieferzeit, kategorie));
                } else {
                    System.out.println("Fehlerhafte JSON-Zeile: " + json);
                }
            }
            System.out.println("Datei erfolgreich importiert.");
        } catch (IOException e) {
            System.out.println("Fehler beim Importieren: " + e.getMessage());
        }
    }

    @Override
    public void sortByNameAscending() {
        itemList.sort(Comparator.comparing(Item::getArtikel));
    }

    @Override
    public void sortByNameDescending() {
        itemList.sort(Comparator.comparing(Item::getArtikel).reversed());
    }

    @Override
    public void sortByPriceAscending() {
        itemList.sort(Comparator.comparingDouble(Item::getPreis));
    }

    @Override
    public void sortByPriceDescending() {
        itemList.sort(Comparator.comparingDouble(Item::getPreis).reversed());
    }
}
