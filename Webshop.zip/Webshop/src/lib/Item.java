package lib;

public interface Item {
    String getMarke();
    void setMarke(String marke);
    String getArtikel();
    void setArtikel(String artikel);
    int getArtikelID();
    void setArtikelID(int artikelID);
    double getPreis();
    void setPreis(double preis);
    String getGroesse();
    void setGroesse(String groesse);
    int getBewertung();
    void setBewertung(int bewertung);
    boolean isVerfuegbarkeit();
    void setVerfuegbarkeit(boolean verfuegbarkeit);
    int getLieferzeit();
    void setLieferzeit(int lieferzeit);
    String getKategorie();
    void setKategorie(String kategorie);

    String toJSON();
    String toCSV();
}
