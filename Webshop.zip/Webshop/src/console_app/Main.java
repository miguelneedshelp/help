package console_app;

import lib.Categories;
import lib.Item;
import lib.ItemManagerImpl;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static ItemManagerImpl<Item> itemManager = new ItemManagerImpl<>();

    public static void main(String[] args) {
        boolean exit = false;

        while (!exit) {
            printMenu();
            int choice = getUserChoice();

            switch (choice) {
                case 1 -> addItem();
                case 2 -> deleteItem();
                case 3 -> updateItem();
                case 4 -> exportToCSV();
                case 5 -> importFromCSV();
                case 6 -> exportToJSON();
                case 7 -> importFromJSON();
                case 8 -> displayAllItems();
                case 9 -> sortItems();
                case 10 -> compareItems();
                case 0 -> exit = true;
                default -> System.out.println("Ungueltige Auswahl. Bitte versuchen Sie es erneut.");
            }
        }
        scanner.close();
    }

    private static void deleteItem() {
        System.out.print("Geben Sie den Index des zu loeschenden Artikels ein: ");
        int index = scanner.nextInt();
        itemManager.delete(index);
    }

    private static void updateItem() {
        System.out.print("Geben Sie den Index des zu aktualisierenden Artikels ein: ");
        int index = scanner.nextInt();

        System.out.print("Neue Marke: ");
        String newMarke = scanner.next();
        System.out.print("Neuer Artikel: ");
        String newArtikel = scanner.next();
        System.out.print("Neue Artikel-ID: ");
        int newArtikelID = scanner.nextInt();
        System.out.print("Neuer Preis: ");
        double newPreis = scanner.nextDouble();
        System.out.print("Neue Grosse: ");
        String newGroesse = scanner.next();
        System.out.print("Neue Bewertung: ");
        int newBewertung = scanner.nextInt();
        System.out.print("Neue Verfuegbarkeit (true/false): ");
        boolean newVerfuegbarkeit = scanner.nextBoolean();
        System.out.print("Neue Lieferzeit: ");
        int newLieferzeit = scanner.nextInt();
        System.out.print("Neue Kategorie: ");
        String newKategorie = scanner.next();

        itemManager.update(index, newMarke, newArtikel, newArtikelID, newPreis, newGroesse, newBewertung, newVerfuegbarkeit, newLieferzeit, newKategorie);
    }

    private static void sortItems() {
        List<Item> itemList = itemManager.getAllItems();
        itemManager.sort(itemList);
        System.out.println("Artikel sortiert.");
    }

    private static void compareItems() {
        List<Item> items = itemManager.getAllItems();
        System.out.print("Index des ersten Artikels eingeben: ");
        int index1 = scanner.nextInt();
        System.out.print("Index des zweiten Artikels eingeben: ");
        int index2 = scanner.nextInt();

        if (index1 < 0 || index1 >= items.size() || index2 < 0 || index2 >= items.size()) {
            System.out.println("Ungueltige Index.");
            return;
        }

        Item item1 = items.get(index1);
        Item item2 = items.get(index2);

        if (item1 instanceof Comparable) {
            @SuppressWarnings("unchecked")
            Comparable<Item> comparableItem1 = (Comparable<Item>) item1;
            System.out.println("Vergleichsergebnis: " + comparableItem1.compareTo(item2));
        } else {
            System.out.println("Die Objekte sind nicht vergleichbar.");
        }
    }

    private static void addItem() {
        try {
            System.out.print("Anzahl vom Artikel eingeben: ");
            int inputartikelAnzahl = scanner.nextInt();
            if (inputartikelAnzahl <= 0) {
                System.out.println("Anzahl kann nicht negativ sein!");
                return;
            }
            scanner.nextLine();

            System.out.print("Name von der Marke eingeben: ");
            String marke = scanner.nextLine();
            if (marke.isEmpty()) {
                System.out.println("Marke kann nicht leer sein!");
                return;
            }

            System.out.print("Name des Items eingeben: ");
            String name = scanner.nextLine();

            System.out.print("Item-ID eingeben (100,000 - 999,999): ");
            int inputArtikelID = scanner.nextInt();
            if (inputArtikelID < 100000 || inputArtikelID > 999999) {
                System.out.println("Nicht im gegebenen Bereich!");
                return;
            }

            System.out.print("Geben Sie den Preis für den Artikel (€): ");
            double inputPreis = scanner.nextDouble();
            if (inputPreis <= 0) {
                System.out.println("Preis kann nicht negativ sein!");
                return;
            }

            String groesse;
            while (true) {
                System.out.print("Groesse vom Artikel eingeben (XXS, XS, S, M, L, XL, XXL) oder Schuhgroesse (EU: 35-52) [ganze Zahlen!] oder \"OS\" (one size): ");
                groesse = scanner.next().toUpperCase();
                if (isValidSize(groesse) || isValidShoeSize(groesse)) {
                    break;
                } else {
                    System.out.println("Ungueltige Groesse! Bitte geben Sie eine gueltige Groesse ein.");
                }
            }

            int bewertung;
            while (true) {
                System.out.print("Bewertung eingeben (1-5 Sterne) [ganze Zahl]: ");
                bewertung = scanner.nextInt();
                if (bewertung >= 1 && bewertung <= 5) {
                    break;
                } else {
                    System.out.println("Ungueltige Bewertung! Bitte geben Sie eine Bewertung zwischen 1 und 5 ein.");
                }
            }

            System.out.print("Verfuegbarkeit (true/false): ");
            boolean availability = scanner.nextBoolean();

            System.out.print("Lieferzeit (Tage): ");
            int deliveryTime = scanner.nextInt();

            String[] categories = {"Neu erschienen", "Icons", "Männer", "Frauen", "Kinder", "Brillen", "Spezielle Stücke", "Homeware", "Geschenke", "Unsere Vision"};
            System.out.println("Kategorie auswaehlen:");
            for (String category : categories) {
                System.out.println(category);
            }

            String category;
            while (true) {
                System.out.print("Bitte geben Sie eine Kategorie ein: ");
                category = scanner.next();
                if (isValidCategory(category, categories)) {
                    break;
                } else {
                    System.out.println("Ungueltige Kategorie! Bitte geben Sie eine gueltige Kategorie ein.");
                }
            }

            for (int i = 0; i < inputartikelAnzahl; i++) {
                itemManager.add(new Categories(marke, name, inputArtikelID + i, inputPreis, groesse, bewertung, availability, deliveryTime, category));
            }
            System.out.println(inputartikelAnzahl + " Artikel erfolgreich hinzugefuegt.");
        } catch (Exception e) {
            System.out.println("Fehler beim Hinzufügen des Artikels: " + e.getMessage());
        }
    }

    private static boolean isValidSize(String size) {
        return size.equals("OS") || size.equals("XXS") || size.equals("XS") || size.equals("S") || size.equals("M") || size.equals("L") || size.equals("XL") || size.equals("XXL");
    }

    private static boolean isValidShoeSize(String size) {
        try {
            int sizeEU = Integer.parseInt(size);
            return (sizeEU >= 35 && sizeEU <= 52);
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private static boolean isValidCategory(String category, String[] categories) {
        for (String validCategory : categories) {
            if (validCategory.equalsIgnoreCase(category)) {
                return true;
            }
        }
        return false;
    }

    private static void displayAllItems() {
        List<Item> items = itemManager.getAllItems();
        for (int i = 0; i < items.size(); i++) {
            System.out.println("Index: " + i + ", " + items.get(i));
        }
    }

    private static void exportToCSV() {
        System.out.print("Geben Sie den Dateinamen für den Export ein: ");
        String fileName = scanner.next();
        itemManager.exportToCSV(fileName);
    }

    private static void importFromCSV() {
        System.out.print("Geben Sie den Dateinamen für den Import ein: ");
        String fileName = scanner.next();
        itemManager.importFromCSV(fileName);
    }

    private static void exportToJSON() {
        System.out.print("Geben Sie den Dateinamen für den Export ein: ");
        String fileName = scanner.next();
        itemManager.exportToJSON(fileName);
    }

    private static void importFromJSON() {
        System.out.print("Geben Sie den Dateinamen für den Import ein: ");
        String fileName = scanner.next();
        itemManager.importFromJSON(fileName);
    }

    private static int getUserChoice() {
        System.out.print("Ihre Auswahl: ");
        return scanner.nextInt();
    }

    private static void printMenu() {
        System.out.println("\n------Menue zum Webshop------\n");

        System.out.println("----Hinzufügen/Löschen/Aktualisieren----");
        System.out.println("1. Artikel hinzufuegen");
        System.out.println("2. Artikel loeschen");
        System.out.println("3. Artikel aktualisieren\n");

        System.out.println("---------Import/Export--------");
        System.out.println("4. Exportieren als CSV");
        System.out.println("5. Importieren von CSV");
        System.out.println("6. Exportieren als JSON");
        System.out.println("7. Importieren von JSON\n");

        System.out.println("--Alle anzeigen/Sortieren/Vergleichen--");
        System.out.println("8. Alle Artikel anzeigen");
        System.out.println("9. Artikel sortieren");
        System.out.println("10. Artikel vergleichen\n");

        System.out.println("0. Beenden");
        System.out.println("-------------------------");
    }
}
