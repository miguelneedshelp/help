package console_web;

import com.htl.miniserver.HTTPRequest;
import com.htl.miniserver.HTTPResponse;

public interface post {
    HTTPResponse onPostRequest(HTTPRequest request);
}
