package lib;

import java.util.List;

interface itemManager<T extends Item> {
    void add(T item);
    void update(int index, String newMarke, String newArtikel, int newArtikelID, double newPreis, String newGroesse, int newBewertung, boolean newVerfuegbarkeit, int newLieferzeit, String newKategorie);

    void update(T updatedItem);

    void delete(int index);

    Categories parseCategory(String line);

    void sort(List<T> list);
    List<T> getAllItems();
    void exportToCSV(String fileName);
    void importFromCSV(String fileName);
    List<T> exportToJSON(String fileName);
    void importFromJSON(String fileName);

    void sortByNameAscending();

    void sortByNameDescending();

    void sortByPriceAscending();

    void sortByPriceDescending();
}
