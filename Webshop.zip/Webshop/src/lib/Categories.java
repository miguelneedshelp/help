package lib;

public class Categories implements Item, Comparable<Categories> {
    private String marke;
    private String artikel;
    private int artikelID;
    private double preis;
    private String groesse;
    private int bewertung;
    private boolean verfuegbarkeit;
    private int lieferzeit;
    private String kategorie; // fuer buttons

    public Categories(String marke, String artikel, int artikelID, double preis, String groesse, int bewertung, boolean verfuegbarkeit, int lieferzeit, String kategorie) {
        this.marke = marke;
        this.artikel = artikel;
        this.artikelID = artikelID;
        this.preis = preis;
        this.groesse = groesse;
        this.bewertung = bewertung;
        this.verfuegbarkeit = verfuegbarkeit;
        this.lieferzeit = lieferzeit;
        this.kategorie = kategorie;
    }

    @Override
    public String getMarke() {
        return marke;
    }

    @Override
    public void setMarke(String marke) {
        this.marke = marke;
    }

    @Override
    public String getArtikel() {
        return artikel;
    }

    @Override
    public void setArtikel(String artikel) {
        this.artikel = artikel;
    }

    @Override
    public int getArtikelID() {
        return artikelID;
    }

    @Override
    public void setArtikelID(int artikelID) {
        this.artikelID = artikelID;
    }

    @Override
    public double getPreis() {
        return preis;
    }

    @Override
    public void setPreis(double preis) {
        this.preis = preis;
    }

    @Override
    public String getGroesse() {
        return groesse;
    }

    @Override
    public void setGroesse(String groesse) {
        this.groesse = groesse;
    }

    @Override
    public int getBewertung() {
        return bewertung;
    }

    @Override
    public void setBewertung(int bewertung) {
        this.bewertung = bewertung;
    }

    @Override
    public boolean isVerfuegbarkeit() {
        return verfuegbarkeit;
    }

    @Override
    public void setVerfuegbarkeit(boolean verfuegbarkeit) {
        this.verfuegbarkeit = verfuegbarkeit;
    }

    @Override
    public int getLieferzeit() {
        return lieferzeit;
    }

    @Override
    public void setLieferzeit(int lieferzeit) {
        this.lieferzeit = lieferzeit;
    }

    @Override
    public String getKategorie() {
        return kategorie;
    }

    @Override
    public void setKategorie(String kategorie) {
        this.kategorie = kategorie;
    }

    @Override
    public String toJSON() {
        return "{" +
                "\"marke\":\"" + marke + "\"," +
                "\"artikel\":\"" + artikel + "\"," +
                "\"artikelID\":" + artikelID + "," +
                "\"preis\":" + preis + "," +
                "\"groesse\":\"" + groesse + "\"," +
                "\"bewertung\":" + bewertung + "," +
                "\"verfuegbarkeit\":" + verfuegbarkeit + "," +
                "\"lieferzeit\":" + lieferzeit + "," +
                "\"kategorie\":\"" + kategorie + "\"" +
                "}";
    }

    @Override
    public String toCSV() {
        return marke + "," + artikel + "," + artikelID + "," + preis + "," + groesse + "," + bewertung + "," + verfuegbarkeit + "," + lieferzeit + "," + kategorie;
    }

    @Override
    public String toString() {
        return "Marke: " + marke + ", Artikel: " + artikel + ", ArtikelID: " + artikelID +
                ", Preis: " + preis + ", Groesse: " + groesse + ", Bewertung: " + bewertung +
                ", Verfuegbarkeit: " + verfuegbarkeit + ", Lieferzeit: " + lieferzeit + ", Kategorie: " + kategorie;
    }

    @Override
    public int compareTo(Categories other) {
        return Integer.compare(this.artikelID, other.artikelID);
    }
}
